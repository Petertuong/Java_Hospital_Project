package  service.FacilityService;

import java.util.ArrayList;

import  dao.FacilityDAO.RoomDAO;
import  dao.FacilityDAO.IRoomDAO;
import  model.Facility.Room;
import  model.Facility.BedStats;
import  service.AbstractService;

/**
 * Room Service - handles room business operations
 * Now includes bed-room sync business logic within proper MVC structure
 */
public class RoomService extends AbstractService<RoomDAO> implements IRoomService {

    private RoomDAO roomdao;  // Concrete type for DAO operations
    private IRoomDAO syncDAO; // Interface type for sync operations

    public RoomService(){
		super();
		this.roomdao = createEntityDAO();
		this.syncDAO = this.roomdao; // Same instance, different interface view
    }

    @Override
    public RoomDAO createEntityDAO() {
        return new RoomDAO();
    }
    
    // ===== Core Room Business Operations =====
    
    @Override
    public Room addRoom(Room room) {
        return roomdao.create(room);
    }

    @Override
    public Integer incrBedsavailable(Room room) {
        room.incrBedsAvailable();
        return roomdao.update(room);
    }

    @Override
    public Integer setBedsavailablezero(Room room) {
        room.setBedsAvialabletozero();
        return roomdao.update(room);
    }

    @Override
    public Integer deleteRoom(Integer roomno) {
        return roomdao.delete(roomno);
    }

    @Override
    public Integer updateRoom(Room room) {
        return roomdao.update(room);
    }

    @Override
    public ArrayList<Room> listRoom() {
        return roomdao.selectAll();
    }

    @Override
    public Room findRoomByNo(Integer roomno) {
        return roomdao.selectById(roomno);
    }

    @Override
    public ArrayList<Room> findRoomByBedsSmaller(Integer num) {
        String condition = "BedsAvailable < " + num;
        return roomdao.selectByCondition(condition);
    }

    @Override
    public ArrayList<Room> findRoomByBedsGreater(Integer num) {
        String condition = "BedsAvailable > " + num;
        return roomdao.selectByCondition(condition);
    }

    // ===== Bed-Room Sync Business Logic =====
    
    /**
     * Update bed availability for a specific room (business logic)
     * @param roomNo The room number to update
     */
    public void updateRoomBedAvailability(int roomNo) {
        // Business rule: Validate room exists first
        Room room = roomdao.selectById(roomNo);
        if (room == null) {
            System.err.println("Cannot update bed availability: Room " + roomNo + " does not exist");
            return;
        }
        
        // Delegate to DAO for database operation
        syncDAO.updateRoomBedAvailability(roomNo);
    }

    /**
     * Update bed availability for all rooms (business logic)
     */
    public void updateAllRoomsBedAvailability() {
        System.out.println("Updating bed availability for all rooms...");
        
        // Get all room numbers from DAO
        ArrayList<Integer> roomNumbers = syncDAO.getAllRoomNumbers();
        
        // Business rule: Update each room individually
        for (Integer roomNo : roomNumbers) {
            syncDAO.updateRoomBedAvailability(roomNo);
        }
        
        System.out.println("All room bed availabilities updated!");
    }

    /**
     * Get bed statistics for a room (business logic)
     * @param roomNo The room number
     * @return BedStats object with room statistics
     */
    public BedStats getRoomBedStats(int roomNo) {
        // Business rule: Validate room exists
        Room room = roomdao.selectById(roomNo);
        if (room == null) {
            System.err.println("Room " + roomNo + " does not exist");
            return new BedStats(0, 0, 0);
        }
        
        // Delegate to DAO for data retrieval
        return syncDAO.getRoomBedStats(roomNo);
    }

    /**
     * Validate bed-room consistency (business logic)
     * @param roomNo The room number to validate
     * @return true if room bed counts are consistent
     */
    public boolean validateRoomBedConsistency(int roomNo) {
        // Business rule: Validate room exists
        Room room = roomdao.selectById(roomNo);
        if (room == null) {
            System.err.println("Room " + roomNo + " does not exist");
            return false;
        }
        
        // Delegate to DAO for validation
        return syncDAO.validateRoomBedConsistency(roomNo);
    }

    /**
     * Validate all rooms' bed consistency (business logic)
     * @return true if all rooms are consistent
     */
    public boolean validateAllRoomsConsistency() {
        ArrayList<Integer> roomNumbers = syncDAO.getAllRoomNumbers();
        boolean allConsistent = true;
        
        for (Integer roomNo : roomNumbers) {
            if (!syncDAO.validateRoomBedConsistency(roomNo)) {
                allConsistent = false;
            }
        }
        
        if (allConsistent) {
            System.out.println("All rooms have consistent bed data");
        } else {
            System.out.println("Some rooms have inconsistent bed data - sync recommended");
        }
        
        return allConsistent;
    }
}
