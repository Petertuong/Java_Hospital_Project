package model.Facility;

/**
 * Data model for bed statistics
 * Contains information about bed counts and occupancy
 */
public class BedStats {
    private int totalBeds;
    private int occupiedBeds; 
    private int availableBeds;
    
    public BedStats(int totalBeds, int occupiedBeds, int availableBeds) {
        this.totalBeds = totalBeds;
        this.occupiedBeds = occupiedBeds;
        this.availableBeds = availableBeds;
    }
    
    // Getters
    public int getTotalBeds() { 
        return totalBeds; 
    }
    
    public int getOccupiedBeds() { 
        return occupiedBeds; 
    }
    
    public int getAvailableBeds() { 
        return availableBeds; 
    }
    
    // Setters
    public void setTotalBeds(int totalBeds) {
        this.totalBeds = totalBeds;
    }
    
    public void setOccupiedBeds(int occupiedBeds) {
        this.occupiedBeds = occupiedBeds;
    }
    
    public void setAvailableBeds(int availableBeds) {
        this.availableBeds = availableBeds;
    }
    
    @Override
    public String toString() {
        return String.format("Total: %d, Occupied: %d, Available: %d", 
                           totalBeds, occupiedBeds, availableBeds);
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        
        BedStats bedStats = (BedStats) obj;
        return totalBeds == bedStats.totalBeds &&
               occupiedBeds == bedStats.occupiedBeds &&
               availableBeds == bedStats.availableBeds;
    }
    
    @Override
    public int hashCode() {
        return totalBeds * 31 + occupiedBeds * 17 + availableBeds;
    }
}