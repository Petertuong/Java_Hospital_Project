package  dao.PersonDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import  dao.DAOInterface;
import  dao.MapperUtil;
import  model.Staff.Nurse;
import  util.DBConnect;

public class NurseDAO implements DAOInterface<Nurse, Integer> {

    @Override
    public Nurse create(Nurse t) {
        String sql = "INSERT INTO nurse (fullname, gender, phoneno, specialization) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            int idx=1;
            ps.setString(idx++, t.getFullname());
            ps.setString(idx++, String.valueOf(t.getGender()));
            ps.setString(idx++, t.getPhoneNo());
            ps.setString(idx, t.getSpecialization());

            int rows = ps.executeUpdate();

            if (rows == 0) return null;

            System.out.println(rows + " row(s) inserted successfully!");


            return t;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Integer update(Nurse t) {
           String sql = "UPDATE nurse " +
                "SET fullname = ?, gender = ?, phoneno = ?, specialization = ?, patient_in_charge = ? " +
                "WHERE nurse_id = ?";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            int idx = 1;
            ps.setString(idx++, t.getFullname());
            ps.setString(idx++, String.valueOf(t.getGender()));
            ps.setString(idx++, t.getPhoneNo());
            ps.setString(idx++, t.getSpecialization());
            ps.setInt(idx++, t.getPatient_in_charge());
            ps.setInt(idx, t.getSID());

            int rows = ps.executeUpdate();

            if (rows == 0) return null;

            System.out.println(rows + " row(s) updated successfully!");


            return t.getPatient_in_charge();

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    // Method to update only patient count - avoids fullname unique constraint issues
    public Integer updatePatientCount(int nurseId, int newPatientCount) {
        String sql = "UPDATE nurse SET patient_in_charge = ? WHERE nurse_id = ?";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, newPatientCount);
            ps.setInt(2, nurseId);

            int rows = ps.executeUpdate();

            if (rows == 0) return null;

            System.out.println(rows + " row(s) nurse patient count updated successfully!");


            return newPatientCount;

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public ArrayList<Nurse> selectAll() {
        ArrayList<Nurse> nurses = new ArrayList<>();
        String sql = "SELECT * from nurse ";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            
            int count = 0;

            while (rs.next()) {

                Nurse n = MapperUtil.mapNurse(rs);

                nurses.add(n);

                ++count;
            }

            System.out.println(count + " row(s) retrieved!");


            return nurses;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Nurse selectById(Integer k) {

        Nurse n = new Nurse();

        String sql = "SELECT * from nurse WHERE nurse_id = ?";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, k);

            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                return null;
            }

            n = MapperUtil.mapNurse(rs);
            
            System.out.println("Retrieved nurse with SID = " + k + " successfully!");


            return n;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public ArrayList<Nurse> selectByCondition(String condition) {
        ArrayList<Nurse> nurses = new ArrayList<>();
        String sql = "SELECT * from nurse " + condition;
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            
            int count = 0;

            while (rs.next()) {
                Nurse n = MapperUtil.mapNurse(rs);

                nurses.add(n);

                ++count;
            }

            System.out.println(count + " rows(s) retrieved!");


            return nurses;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Integer delete(Integer k) {
        String sql = "DELETE from Nurse " +
                    "WHERE nurse_id = ?";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, k);

            int rows = ps.executeUpdate();

            if (rows == 0) return null;

            System.out.println(rows + " rows deleted successfully!");


            return 1;

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

}
