package  dao.FacilityDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import  dao.DAOInterface;
import  dao.MapperUtil;
import  model.Facility.Room;
import  util.DBConnect;

public class RoomDAO implements DAOInterface<Room, Integer> {

    @Override
    public Room create(Room t) {
        String sql = "INSERT INTO room (roomno, bedsavailable) VALUES (?, ?)";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            int idx=1;
            ps.setInt(idx++, t.getRoomNo());
            ps.setInt(idx, t.getBedsAvailable());

            int rows = ps.executeUpdate();

            if (rows == 0) return null;

            System.out.println(rows + " row(s) inserted successfully!");

            DBConnect.closeConnection(conn);
            return t;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Integer update(Room t) {
       String sql = "UPDATE room " +
                    "SET bedsavailable = ?" + 
                    "WHERE roomno= ?";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            int idx = 1;
            ps.setInt(idx, t.getBedsAvailable());

            int rows = ps.executeUpdate();

            if (rows == 0) return null;

            System.out.println(rows + " row(s) updated successfully!");

            DBConnect.closeConnection(conn);
            return 1;

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public Integer delete(Integer roomno) {
       String sql = "DELETE from room " +
                    "WHERE roomno = ?";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, roomno);

            int rows = ps.executeUpdate();

            if (rows == 0) return null;

            System.out.println(rows + " row(s) deleted successfully!");

            DBConnect.closeConnection(conn);
            return 1;

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public ArrayList<Room> selectAll() {
        ArrayList<Room> rooms = new ArrayList<>();
        String sql = "SELECT * from room ";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            
            int count = 0;

            while (rs.next()) {

                Room r = MapperUtil.mapRoom(rs);

                rooms.add(r);

                ++count;
            }

            System.out.println(count + " row(s) retrieved!");

            DBConnect.closeConnection(conn);
            return rooms;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Room selectById(Integer k) {

        Room r = new Room();
        String sql = "SELECT * from room WHERE roomno = ?";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, k);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
 
                r = MapperUtil.mapRoom(rs);

            }
            
            if(rs.wasNull()){
                return null;
            }
            
            System.out.println("Retrieved room with roomno = " + k + " successfully!");

            DBConnect.closeConnection(conn);
            return r;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public ArrayList<Room> selectByCondition(String condition) {
        ArrayList<Room> rooms = new ArrayList<>();
        String sql = "SELECT * from room WHERE " + condition;
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            
            int count = 0;

            while (rs.next()) {

                Room r = MapperUtil.mapRoom(rs);

                rooms.add(r);

                ++count;
            }

            System.out.println(count + " row(s) retrieved!");

            DBConnect.closeConnection(conn);
            return rooms;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
