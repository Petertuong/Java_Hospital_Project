package  dao.TreatmentDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import  dao.DAOInterface;
import  dao.MapperUtil;
import  model.Treatment.Prescription;
import  util.DBConnect;

public class PrescriptionDAO implements DAOInterface<Prescription, Integer> {

    @Override
    public Prescription create(Prescription t) {
        String sql = "INSERT INTO prescription (description, doctor_id, dosage_per_day, drug_id, number_of_day, ssn) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            int idx=1;

            ps.setString(idx++, t.getDescription());
            
            // Handle null doctor
            if (t.getDoctor() != null) {
                ps.setInt(idx++, t.getDoctor().getSID());
            } else {
                ps.setNull(idx++, java.sql.Types.INTEGER);
            }
            
            ps.setInt(idx++, t.getDosagePerDay());
            
            // Handle null medicine
            if (t.getMedicine() != null) {
                ps.setInt(idx++, t.getMedicine().getDrugID());
            } else {
                ps.setNull(idx++, java.sql.Types.INTEGER);
            }
            
            ps.setInt(idx++, t.getNumberOfDay());
            ps.setString(idx, t.getPatient().getSSN());

            int rows = ps.executeUpdate();

            if (rows == 0) return null;

            // Get the generated treatment_id
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int generatedId = generatedKeys.getInt(1);
                    t.setTreatmentID(generatedId);
                }
            }

            System.out.println(rows + " row(s) inserted successfully!");

            DBConnect.closeConnection(conn);

            return t;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Integer update(Prescription t) {
       String sql = "UPDATE prescription " +
                    "SET description = ?, dosage_per_day = ?, drug_id = ?, number_of_day = ? " + 
                    "WHERE treatment_id = ?";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            int idx = 1;
            ps.setString(idx++, t.getDescription());
            ps.setInt(idx++, t.getDosagePerDay());
            
            // Handle null medicine
            if (t.getMedicine() != null) {
                ps.setInt(idx++, t.getMedicine().getDrugID());
            } else {
                ps.setNull(idx++, java.sql.Types.INTEGER);
            }
            
            ps.setInt(idx++, t.getNumberOfDay());
            ps.setInt(idx, t.getTreatmentID());

            int rows = ps.executeUpdate();

            if (rows == 0) return null;

            System.out.println(rows + " row(s) updated successfully!");

            DBConnect.closeConnection(conn);

            return 1;

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public Integer delete(Integer k) {
       String sql = "DELETE from prescription " +
                    "WHERE treatment_id = ?";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, k);

            int rows = ps.executeUpdate();

            if (rows == 0) return null;

            System.out.println(rows + " row(s) deleted successfully!");

            DBConnect.closeConnection(conn);

            return 1;

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public ArrayList<Prescription> selectAll() {
        ArrayList<Prescription> prescriptions = new ArrayList<>();
        String sql = "SELECT * from prescription pr " +
                    "LEFT JOIN doctor d ON (d.doctor_id = pr.doctor_id) " +
                    "LEFT JOIN patient p ON (p.ssn = pr.ssn) " +
                    "LEFT JOIN medicine m ON (m.drug_id = pr.drug_id)";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            
            int count = 0;

            while (rs.next()) {
                
                Prescription pr = MapperUtil.mapPrescription(rs);

                prescriptions.add(pr);

                ++count;
            }

            System.out.println(count + " row(s) retrieved!");

            DBConnect.closeConnection(conn);

            return prescriptions;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Prescription selectById(Integer k) {

        Prescription pr = new Prescription();
        String sql = "SELECT * from prescription pr " +
                    "LEFT JOIN doctor d ON (d.doctor_id = pr.doctor_id) " +
                    "LEFT JOIN patient p ON (p.ssn = pr.ssn) " +
                    "LEFT JOIN medicine m ON (m.drug_id = pr.drug_id) " +
                    "WHERE treatment_id = ?";
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, k);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
 
                pr = MapperUtil.mapPrescription(rs);

            }
            if(rs.wasNull()){
                return null;
            }            
            System.out.println("Retrieved prescription with treatment_id = " + k + " successfully!");

            DBConnect.closeConnection(conn);

            return pr;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public ArrayList<Prescription> selectByCondition(String condition) {
        ArrayList<Prescription> prescriptions = new ArrayList<>();
        String sql = "SELECT * from prescription pr " +
                    "JOIN doctor d ON (d.doctor_id = pr.doctor_id)" +
                    "JOIN patient p ON (p.ssn = pr.ssn)" +
                    "JOIN medicine m ON (m.drug_id = pr.drug_id) " + 
                    "WHERE " + condition;
        try (Connection conn = DBConnect.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            
            int count = 0;

            while (rs.next()) {

                Prescription pr = MapperUtil.mapPrescription(rs);

                prescriptions.add(pr);

                ++count;
            }

            System.out.println(count + " row(s) retrieved!");

            DBConnect.closeConnection(conn);

            return prescriptions;

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
