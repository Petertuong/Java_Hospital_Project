package ui;

import ui.SessionManager.Role;
import util.DBConnect;
import util.PasswordUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AuthManager {

    // Minimal user model used by UI
    public static class User {
        private final String username;
        private final Role role;

        public User(String username, Role role) {
            this.username = username;
            this.role = role;
        }

        public String getUsername() { return username; }
        public Role getRole() { return role; }
    }

    static {
        // Ensure users table exists and create default accounts if missing
        ensureUsersTable();
        ensureDefaultAccounts();
    }

    private static void ensureUsersTable() {
        String sql = "CREATE TABLE IF NOT EXISTS Users ("
                + "id INT AUTO_INCREMENT PRIMARY KEY,"
                + "username VARCHAR(100) NOT NULL UNIQUE,"
                + "password_hash VARCHAR(256) NOT NULL,"
                + "salt VARCHAR(64) NOT NULL,"
                + "role VARCHAR(32) NOT NULL,"
                + "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
                + ") ENGINE=InnoDB";

        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void ensureDefaultAccounts() {
        try {
            if (!exists("admin")) {
                register("admin", "admin123", Role.ADMIN);
            }
            if (!exists("staff")) {
                register("staff", "staff123", Role.STAFF);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static User authenticate(String username, String password) {
        if (username == null || password == null) return null;

        String sql = "SELECT password_hash, salt, role FROM Users WHERE username = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String hash = rs.getString("password_hash");
                    String salt = rs.getString("salt");
                    String roleStr = rs.getString("role");
                    boolean ok = PasswordUtil.verify(password, salt, hash);
                    if (ok) {
                        Role role = Role.valueOf(roleStr);
                        return new User(username, role);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static boolean exists(String username) {
        String sql = "SELECT COUNT(*) FROM Users WHERE username = ?";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public static void registerStaff(String username, String password) {
        register(username, password, Role.STAFF);
    }

    public static void register(String username, String password, Role role) {
        if (username == null || password == null) throw new IllegalArgumentException("Invalid input");
        if (username.trim().isEmpty() || password.trim().isEmpty()) throw new IllegalArgumentException("Username and password are required.");
        if (exists(username)) throw new IllegalArgumentException("Username already exists.");

        String salt = PasswordUtil.generateSalt();
        String hash = PasswordUtil.hash(password, salt);

        String sql = "INSERT INTO Users (username, password_hash, salt, role) VALUES (?,?,?,?)";
        try (Connection conn = DBConnect.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, hash);
            ps.setString(3, salt);
            ps.setString(4, role.name());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to register user", e);
        }
    }
}
